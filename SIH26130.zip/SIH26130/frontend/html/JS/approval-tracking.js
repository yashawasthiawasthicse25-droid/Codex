const approvalTrackingApi = "/api/approval-tracking";
const portalStatuses = ["SUBMITTED", "UNDER_SCRUTINY", "DOCUMENT_VERIFICATION", "QUERY_RAISED", "APPROVED", "REJECTED"];
let trackedApprovals = [];

function trackingEscape(value) {
    return String(value ?? "").replace(/[&<>"']/g, character => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;" }[character]));
}

function vaultValue(key) {
    return String(records[key]?.fieldValue || "").trim();
}

function setTrackingMessage(message, error = false) {
    const element = document.getElementById("approvalEntryMessage");
    element.textContent = message;
    element.className = error ? "error" : "success";
}

function renderVaultPreview() {
    const preview = document.getElementById("approvalVaultPreview");
    const permission = document.getElementById("approvalVaultPermission").checked;
    if (!permission) {
        preview.hidden = true;
        preview.innerHTML = "";
        return;
    }
    const sharedFields = [["Business", "business_name"], ["Industry", "industry"], ["Owner", "owner_name"], ["Email", "email"], ["Phone", "phone_number"], ["Location", "district"]];
    preview.innerHTML = `<strong>Information Vault details ready to share</strong><div>${sharedFields.map(([label, key]) => `<span><b>${label}</b>${trackingEscape(vaultValue(key) || "Not entered")}</span>`).join("")}</div>`;
    preview.hidden = false;
}

document.getElementById("approvalVaultPermission").addEventListener("change", renderVaultPreview);
document.getElementById("fillFromVaultButton").addEventListener("click", () => {
    document.getElementById("approvalVaultPermission").checked = true;
    renderVaultPreview();
    setTrackingMessage("Information Vault values are ready and will be shared with your permission.");
});

function renderTrackedApprovals() {
    const count = status => trackedApprovals.filter(item => item.currentStatus === status).length;
    document.getElementById("trackingTotal").textContent = trackedApprovals.length;
    document.getElementById("trackingApproved").textContent = count("APPROVED");
    document.getElementById("trackingReview").textContent = count("UNDER_SCRUTINY") + count("DOCUMENT_VERIFICATION");
    document.getElementById("trackingDocuments").textContent = count("QUERY_RAISED");
    document.getElementById("trackingBlocked").textContent = count("REJECTED");
    document.getElementById("trackingProgress").textContent = `${trackedApprovals.length ? Math.round((count("APPROVED") / trackedApprovals.length) * 100) : 0}%`;
    document.getElementById("trackingProgressBar").style.width = document.getElementById("trackingProgress").textContent;
    document.getElementById("approvalCards").innerHTML = trackedApprovals.map(item => `<article class="approval-card">
        <div class="approval-card-header"><div><span class="demo-badge">FAKE PORTAL</span><h3>${trackingEscape(item.approvalName)}</h3><p>${trackingEscape(item.department)}</p></div><span class="approval-status-badge blue">${trackingEscape(item.currentStatus.replaceAll("_", " "))}</span></div>
        <div class="approval-card-grid"><span><b>Application</b>${trackingEscape(item.applicationId)}</span><span><b>Last checked</b>${new Date(item.lastCheckedAt).toLocaleString("en-IN")}</span><span><b>Email</b>${trackingEscape(item.contact?.email)}</span><span><b>Phone</b>${trackingEscape(item.contact?.phone)}</span></div>
    </article>`).join("") || '<div class="tracking-empty">No portal applications submitted yet.</div>';
}

async function refreshTrackedApprovals() {
    try {
        const response = await fetch(`${approvalTrackingApi}/applications`);
        const result = await response.json();
        if (!response.ok || !result.success) throw new Error(result.error || "Could not check portal status.");
        trackedApprovals = result.data || [];
        renderTrackedApprovals();
    } catch (error) { setTrackingMessage(`Status check unavailable: ${error.message}`, true); }
}

document.getElementById("approvalEntryForm").addEventListener("submit", async event => {
    event.preventDefault();
    const payload = {
        permissionToUseVault: document.getElementById("approvalVaultPermission").checked,
        approval: { approvalName: document.getElementById("newApprovalName").value.trim(), department: document.getElementById("newApprovalDepartment").value.trim() },
        documents: document.getElementById("newDocumentsRequired").value.split(",").map(item => item.trim()).filter(Boolean),
        business: {
            businessName: vaultValue("business_name"), businessType: vaultValue("business_type"), industry: vaultValue("industry"), state: vaultValue("state"), district: vaultValue("district"), investment: vaultValue("total_investment"), landArea: vaultValue("land_area"), employees: vaultValue("current_employees"), contactName: vaultValue("owner_name"), email: vaultValue("email"), phone: vaultValue("phone_number")
        }
    };
    const missingVaultFields = ["business_name", "email", "phone_number"].filter(key => !vaultValue(key));
    if (missingVaultFields.length) {
        setTrackingMessage("Complete Business name, Email, and Phone number in the Information Vault before applying.", true);
        return;
    }
    setTrackingMessage("Submitting to the fake government portal...");
    try {
        const response = await fetch(`${approvalTrackingApi}/applications`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
        const result = await response.json();
        if (!response.ok || !result.success) throw new Error(result.error || "Application failed.");
        event.target.reset();
        setTrackingMessage(`Application ${result.data.applicationId} submitted. Status checks run automatically.`);
        await refreshTrackedApprovals();
    } catch (error) { setTrackingMessage(error.message, true); }
});

refreshTrackedApprovals();
window.setInterval(refreshTrackedApprovals, 10000);