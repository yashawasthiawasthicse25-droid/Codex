const express = require("express");
const { notifyStatusChange, getNotificationLog } = require("../services/approvalNotificationService");

const router = express.Router();
const portalUrl = process.env.FAKE_GOVERNMENT_PORTAL_URL || "http://localhost:3000";
const trackedApplications = new Map();
const pollIntervalMs = Math.max(Number(process.env.APPROVAL_POLL_INTERVAL_MS || 10000), 5000);

function toPortalPayload(body) {
    const business = body.business || {};
    const approval = body.approval || {};
    return {
        business: {
            businessName: business.businessName,
            businessType: business.businessType,
            industry: business.industry,
            state: business.state,
            district: business.district,
            investment: Number(business.investment || 0),
            landArea: Number(business.landArea || 0),
            employees: Number(business.employees || 0),
            contactName: business.contactName,
            phone: business.phone,
            email: business.email
        },
        approval: {
            approvalCode: approval.approvalCode || "CUSTOM",
            approvalName: approval.approvalName,
            department: approval.department
        },
        documents: (body.documents || []).map((documentName, index) => ({
            documentCode: `VAULT_DOC_${index + 1}`,
            documentName
        }))
    };
}

async function getPortalStatus(applicationId) {
    const response = await fetch(`${portalUrl}/api/applications/${encodeURIComponent(applicationId)}`);
    if (!response.ok) throw new Error(`Fake government portal returned ${response.status}.`);
    return response.json();
}

async function advanceDemoPortal(tracked) {
    const progression = { SUBMITTED: "UNDER_SCRUTINY", UNDER_SCRUTINY: "DOCUMENT_VERIFICATION", DOCUMENT_VERIFICATION: "APPROVED" };
    const nextStatus = progression[tracked.currentStatus];
    const submittedAt = new Date(tracked.submittedAt || tracked.lastCheckedAt).getTime();
    const stepDelay = Math.max(Number(process.env.DEMO_STATUS_INTERVAL_MS || 10000), 5000);
    if (!nextStatus || Date.now() - submittedAt < stepDelay * (tracked.statusHistory?.length + 1 || 1)) return;
    await fetch(`${portalUrl}/api/applications/${encodeURIComponent(tracked.applicationId)}/status`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: nextStatus, remarks: "Automatic demo status progression." })
    });
}

async function pollApplication(tracked) {
    await advanceDemoPortal(tracked);
    const result = await getPortalStatus(tracked.applicationId);
    const portalApplication = result.application;
    if (!portalApplication || portalApplication.status === tracked.currentStatus) return tracked;

    const previousStatus = tracked.currentStatus;
    tracked.previousStatus = previousStatus;
    tracked.currentStatus = portalApplication.status;
    tracked.lastCheckedAt = new Date();
    tracked.statusHistory = tracked.statusHistory || [];
    tracked.statusHistory.unshift({ previousStatus, newStatus: tracked.currentStatus, changedAt: tracked.lastCheckedAt });
    await notifyStatusChange({ application: tracked, previousStatus, newStatus: tracked.currentStatus });
    return tracked;
}

router.post("/applications", async (req, res) => {
    try {
        if (req.body.permissionToUseVault !== true) return res.status(400).json({ success: false, error: "Permission to use Information Vault data is required." });
        const payload = toPortalPayload(req.body);
        if (!payload.business.businessName || !payload.business.email || !payload.business.phone || !payload.approval.approvalName || !payload.approval.department) {
            return res.status(400).json({ success: false, error: "Business name, email, phone, approval name, and department are required." });
        }
        const response = await fetch(`${portalUrl}/api/applications`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
        const result = await response.json();
        if (!response.ok || !result.success) return res.status(502).json({ success: false, error: result.message || "Fake government portal submission failed." });

        const tracked = {
            ...payload.approval,
            applicationId: result.applicationId,
            currentStatus: result.status,
            previousStatus: null,
            business: payload.business,
            contact: { email: payload.business.email, phone: payload.business.phone },
            documents: payload.documents,
            submittedAt: new Date(),
            lastCheckedAt: new Date(),
            statusHistory: []
        };
        trackedApplications.set(tracked.applicationId, tracked);
        res.status(201).json({ success: true, data: tracked });
    } catch (error) {
        res.status(502).json({ success: false, error: error.message });
    }
});

router.get("/applications", async (req, res) => {
    const applications = [];
    for (const tracked of trackedApplications.values()) {
        try { await pollApplication(tracked); } catch (error) { tracked.lastPollError = error.message; }
        applications.push(tracked);
    }
    res.json({ success: true, data: applications, notifications: getNotificationLog() });
});

router.get("/notifications", (req, res) => res.json({ success: true, data: getNotificationLog() }));

setInterval(async () => {
    for (const tracked of trackedApplications.values()) {
        try { await pollApplication(tracked); } catch (error) { tracked.lastPollError = error.message; }
    }
}, pollIntervalMs).unref();

module.exports = router;